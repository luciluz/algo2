
template <class T>
Conjunto<T>::Conjunto(): _raiz(nullptr), _size(0) {}

template <class T>
Conjunto<T>::~Conjunto() { 
    // Completar
    while(this->_raiz != nullptr){
        delete _raiz;
    }
}

template <class T>
bool Conjunto<T>::pertenece(const T& clave) const {
    Nodo* actual = _raiz;
    bool res = false;
    while(actual != nullptr && !res) {
        if (clave == actual->valor) {
            res = true;

        } else {
            if (clave < actual->valor) {
                actual = _raiz->izq;
            } else {
                actual = _raiz->der;
            }
        }
    }
    return res;
}

template <class T>
void Conjunto<T>::insertar(const T& clave) {
    if(!pertenece(clave)){
        Nodo* actual = _raiz;
        if(actual == nullptr){
            new Nodo(clave) = actual;
            actual->valor = clave;
        } else{
            if(clave < actual->valor){
                actual = actual->izq;
            } else{
                actual = actual->der;
            }
        }
    }
}

template <class T>
void Conjunto<T>::remover(const T&) {
    assert(false);
}

template <class T>
const T& Conjunto<T>::siguiente(const T& clave) {
    assert(false);
}

template <class T>
const T& Conjunto<T>::minimo() const {
    assert(false);
}

template <class T>
const T& Conjunto<T>::maximo() const {
    assert(false);
}

template <class T>
unsigned int Conjunto<T>::cardinal() const {
    return this->_size;
}

template <class T>
void Conjunto<T>::mostrar(std::ostream&) const {
    assert(false);
}

