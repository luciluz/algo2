
template <class T>
Conjunto<T>::Conjunto(): _raiz(nullptr), _size(0) {}

template <class T>
Conjunto<T>::~Conjunto() { 
    /* // Completar
    while(this->_raiz != nullptr){
        delete _raiz;
    } */
}

template <class T>
bool Conjunto<T>::pertenece(const T& clave) const {
    Nodo* actual = _raiz;
    bool res = false;
    while(actual != nullptr && !res) {
        if (clave == actual->valor) {
            res = true;

        } else {
            if (clave < actual->valor) {
                actual = actual->izq;
            } else {
                actual = actual->der;
            }
        }
    }
    return res;
}

template <class T>
void Conjunto<T>::insertar(const T& clave) {
    if (!pertenece(clave)) {
        Nodo* actual = _raiz;
        Nodo* padre = nullptr;
        while(actual != nullptr){
            padre = actual;
            if(clave < actual->valor){
                actual = actual->izq;
            } else{
                actual = actual->der;
            }
        }
        Nodo* nuevo = new Nodo(clave);
        if(padre == nullptr){
            _raiz = nuevo;
        } else{
            if(clave < padre->valor){
                padre->izq = nuevo;
            } else{
                padre->der = nuevo;
            }
        }
        _size++;
    }
}


template <class T>
void Conjunto<T>::remover(const T& clave) {
    if(pertenece(clave)){
        Nodo* aBorrar = buscar(clave);

        if(aBorrar->izq == nullptr && aBorrar->der == nullptr){
            delete aBorrar;
            _size--;
            return;
        }

        Nodo* padre = buscarPadre(aBorrar);
        if(aBorrar->izq == nullptr){
            if(padre->izq == aBorrar){
                padre->izq = aBorrar->der;
            } else{
                padre->der = aBorrar->der;
            }
            delete aBorrar;
            _size--;
            return;
        }
        if(aBorrar->der == nullptr){
            if(padre->izq == aBorrar){
                padre->izq = aBorrar->izq;
            } else{
                padre->der = aBorrar->izq;
            }
            delete aBorrar;
            _size--;
            return;
        } else{
            Nodo* sucesor = buscoSucesor(clave);
            Nodo* padreSucesor = buscarPadre(sucesor);

            aBorrar->valor = sucesor->valor;
            padreSucesor->izq = sucesor->der;
            delete sucesor;
            _size--;
        }
    }
}

template<class T>
typename Conjunto<T>::Nodo* Conjunto<T>::buscar(const T &clave) const {
    Nodo* actual = _raiz;
    Nodo* padre = nullptr;
    while(actual->valor != clave){
        padre = actual;
        actual = actual->valor < clave ? actual->der : actual->izq;
    }
    return actual;
}

template<class T>
typename Conjunto<T>::Nodo* Conjunto<T>::buscarPadre(Conjunto::Nodo* nodo) const {
    Nodo* actual = _raiz;
    Nodo* padre = nullptr;
    while(actual != nodo){
        padre = actual;
        actual = actual->valor < nodo->valor ? actual->der : actual->izq;
    }
    return padre;
}

template<class T>
typename Conjunto<T>::Nodo *Conjunto<T>::buscoSucesor(const T &clave) const {
    Nodo* actual = buscar(clave);
    Nodo* sucesor = actual->der;
    while(sucesor->izq != nullptr){
        sucesor = sucesor->izq;
    }
    return sucesor;
}

template <class T>
const T& Conjunto<T>::siguiente(const T& clave) {
    Nodo* actual = buscar(clave);
    Nodo* padre = buscarPadre(actual);
    while(actual->izq !=)
}

template <class T>
const T& Conjunto<T>::minimo() const {
    Nodo* actual = _raiz;
    Nodo* padre = nullptr;

    while(actual->izq != nullptr){
        padre = actual;
        actual = actual->izq;
    }
    return actual->valor;

}

template <class T>
const T& Conjunto<T>::maximo() const {
    Nodo* actual = _raiz;
    Nodo* padre = nullptr;

    while(actual->der != nullptr){
        padre = actual;
        actual = actual->der;
    }
    return actual->valor;
}

template <class T>
unsigned int Conjunto<T>::cardinal() const {
    return this->_size;
}

template <class T>
void Conjunto<T>::mostrar(std::ostream&) const {
    assert(false);
}

